README
--------------------------

Install:

Upload all content of the main directory, excluding 'debug.php' and the directorys 'docs' and 'updates', to your webserver and grant higher directorys enough access to let install.php create an setup.php file during the installation that keeps your database-settings. Next open your browser and point it to the install.php file that gives you further instructions.


Update from older ClanSphere Versions:

Apply the SQL patch (if a new one is available inside the 'updates' directory, else skip this) file by loading it inside the browser window (menu point when logged in as admin: System -> Database -> Import). Next upload all content of the main directory, excluding 'debug.php' and the directorys 'docs' and 'updates', to your webserver and grant upload directorys enough access for file uploads to them.


Help:

Send questions and support requests to #clansphere on irc quakenet or the board at http://www.clansphere.net

Enjoy testing and please send us feedback to make it one of the best clan web-cms that are available opensource and free

your ClanSphere Team