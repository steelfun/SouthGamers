<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['create']   = 3;
$axx_file['edit']   = 4;
$axx_file['manage']   = 3;
$axx_file['options'] = 5;
$axx_file['remove']   = 5;