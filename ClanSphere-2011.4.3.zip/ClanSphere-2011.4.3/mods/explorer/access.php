<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['roots']    = 5;
$axx_file['create']    = 5;
$axx_file['edit']    = 5;
$axx_file['remove']    = 5;
$axx_file['chmod']    = 5;
$axx_file['create_dir']  = 5;
$axx_file['information']= 5;
$axx_file['view']    = 5;
$axx_file['upload']    = 5;