<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['view']   = 3;
$axx_file['center'] = 3;

$axx_file['manage']    = 4;
$axx_file['create']    = 4;
$axx_file['edit']      = 4;
$axx_file['account']   = 4;
$axx_file['options']   = 4;
$axx_file['view_cash'] = 4;
$axx_file['remove']    = 5;