<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['options'] = 5;
$axx_file['upload']  = 0;