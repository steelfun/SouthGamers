<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['403']  = 0;
$axx_file['404']  = 0;
$axx_file['500']  = 0;
