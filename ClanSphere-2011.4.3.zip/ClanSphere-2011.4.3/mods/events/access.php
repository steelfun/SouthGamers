<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['list']           = 1;
$axx_file['agenda']         = 1;
$axx_file['view']           = 1;

$axx_file['create']         = 3;
$axx_file['edit']           = 3;
$axx_file['center']         = 2;
$axx_file['signin']         = 2;
$axx_file['signout']        = 2;
$axx_file['manage']         = 3;
$axx_file['picture']        = 3;
$axx_file['remove']         = 3;
$axx_file['options']        = 5;

$axx_file['guests']         = 2;
$axx_file['guestslatest']   = 3;
$axx_file['guestsmulti']    = 5;
$axx_file['guestsadm']      = 5;
$axx_file['guestsdel']      = 5;
$axx_file['guestsnew']      = 5;
$axx_file['guestsprint']    = 5;
$axx_file['guestsearch']    = 5;

$axx_file['com_create']     = 1;
$axx_file['com_edit']       = 2;
$axx_file['com_remove']     = 5;

$axx_file['calendar']       = 1;
$axx_file['timer']          = 1;
$axx_file['nav_birthday']   = 1;