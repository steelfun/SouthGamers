<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['optimize']    = 5;
$axx_file['roots']      = 5;
$axx_file['import']     = 5;
$axx_file['export']     = 5;
$axx_file['statistic']  = 5;