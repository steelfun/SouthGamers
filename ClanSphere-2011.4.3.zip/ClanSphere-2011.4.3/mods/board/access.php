<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['create']       = 3;
$axx_file['edit']         = 3;
$axx_file['manage']       = 3;
$axx_file['sort']         = 3;
$axx_file['thread_cut']   = 4;
$axx_file['remove']       = 4;
$axx_file['delatt_admin'] = 5;
$axx_file['options']      = 5;
$axx_file['metadata']     = 5;

$axx_file['report']       = 2;
$axx_file['reportdel']    = 4;
$axx_file['reportdone']   = 4;
$axx_file['reportlist']   = 4;

$axx_file['new']     = 1; 
$axx_file['active']  = 1; 
$axx_file['toplist'] = 1; 
$axx_file['search']  = 1;
$axx_file['list']    = 1;
$axx_file['listcat'] = 1;
$axx_file['thread']  = 1; 
$axx_file['users']   = 1;
$axx_file['toplist'] = 1;
$axx_file['stats']   = 1;

$axx_file['newabo']            = 2;
$axx_file['delabo']            = 2;        
$axx_file['delatt']            = 2;
$axx_file['attachments']       = 2;
$axx_file['attachments_admin'] = 4;
$axx_file['center']            = 2;  
$axx_file['avatar']            = 2;
$axx_file['signature']         = 2;
$axx_file['thread_add']        = 2;
$axx_file['thread_edit']       = 2;  
$axx_file['thread_remove']     = 2;
$axx_file['com_create']        = 2;
$axx_file['com_edit']          = 2;
$axx_file['com_remove']        = 2;
$axx_file['modpanel_q']        = 2;
$axx_file['mark']              = 2;