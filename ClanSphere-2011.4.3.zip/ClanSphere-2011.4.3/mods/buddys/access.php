<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['create']  = 2;
$axx_file['center']  = 2;
$axx_file['remove']  = 2;
$axx_file['edit']    = 2;
$axx_file['users']    = 0;