<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['new']    = 1;
$axx_file['manage']    = 3;
$axx_file['view']    = 3;
$axx_file['remove']    = 5;
$axx_file['options']    = 5;
