<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

cs_redirect('', 'contact', 'mail');