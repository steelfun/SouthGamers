<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['list']         = 1;
$axx_file['mail']         = 1;
$axx_file['send']         = 1;
$axx_file['imprint']      = 0;
$axx_file['manage']       = 3;
$axx_file['archive']      = 3;
$axx_file['view']         = 3;
$axx_file['answer']       = 4;
$axx_file['delete']       = 5; 
$axx_file['imp_edit']     = 5;
$axx_file['mailsig_edit'] = 5;
$axx_file['options']      = 5;
$axx_file['blocklist']    = 5;