<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['online']     = 1;
$axx_file['stats']     = 1;
$axx_file['statsyear']   = 1;
$axx_file['statsall']    = 1;

$axx_file['manage']     = 3;

$axx_file['empty']     = 5;
$axx_file['reset']     = 5;
$axx_file['options']   = 5;