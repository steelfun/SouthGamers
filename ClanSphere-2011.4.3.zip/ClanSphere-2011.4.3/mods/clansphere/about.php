<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

// Please do NOT modify, rename or delete this file!
// You MUST place a visible hyperlink to this file in your templates!
// The license is a so called "new bsd license"

$cs_lang = cs_translate('clansphere');

$data = array();

echo cs_subtemplate(__FILE__,$data,'clansphere','about');