<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

require_once 'mods/clansphere/sec_func.php';
echo cs_cspnews(1);