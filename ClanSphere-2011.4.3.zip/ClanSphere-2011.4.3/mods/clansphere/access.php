<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$axx_file['about']         = 0;
$axx_file['admin']         = 3;
$axx_file['cache']         = 4;
$axx_file['system']        = 4;
$axx_file['lang_list']     = 4;
$axx_file['lang_view']     = 4;
$axx_file['lang_validate'] = 5;
$axx_file['support']       = 4;
$axx_file['temp_list']     = 4;
$axx_file['temp_view']     = 4;
$axx_file['themes_list']   = 4;
$axx_file['themes_view']   = 4;
$axx_file['options']       = 5;
$axx_file['software']      = 5;
$axx_file['storage']       = 5;
$axx_file['variables']     = 5;
$axx_file['metatags']      = 5;
$axx_file['navmeta']       = 5;
$axx_file['version']       = 5;
$axx_file['sec_news']      = 5;
$axx_file['charset']       = 5;