<?php
$cs_lang['mod_name']  = 'Logs';
$cs_lang['mod_text']  = 'Aktionen und Fehler ansehen';

$cs_lang['wizard'] = 'Assistent';
$cs_lang['task_done'] = 'Aufgabe erledigt markieren';

$cs_lang['head_view']  = 'Details';
$cs_lang['body_view']  = 'Genaue Informationen &uuml;ber diesen Logeintrag.';
$cs_lang['head_roots'] = 'Basis';

$cs_lang['log_date']  = 'Datum/Uhrzeit:';
$cs_lang['error_2']  = 'Verursacht in:';
$cs_lang['ip']     = 'IP Addresse:';
$cs_lang['browser']  = 'Browser:'; 
$cs_lang['details'] = 'Details';
$cs_lang['dname']  = 'Datei Name';
$cs_lang['errors']  = 'Fehler / Anzahl';
$cs_lang['lev_2'] = 'Action Logs';
$cs_lang['lev_1'] = 'Error Logs';
$cs_lang['ok'] = 'Anzeigen';
$cs_lang['error'] = 'Fehler';

$cs_lang['del'] = 'L&ouml;schen';
$cs_lang['down'] = 'Download';