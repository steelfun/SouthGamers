<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$com_lang['name']     = 'German';
$com_lang['short']    = 'de';
$com_lang['dateset']  = 'd.m.Y';
$com_lang['timeset']  = 'H:i';
$com_lang['dtcon']    = 'um';
$com_lang['timename'] = 'Uhr';
