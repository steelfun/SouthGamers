<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name'] = 'Forumr&auml;nge';
$cs_lang['mod_text'] = 'Forumr&auml;nge verwalten und erstellen';

$cs_lang['body'] = 'Bitte alle Felder mit * ausf&uuml;llen';

$cs_lang['min'] = 'Ab Beitr&auml;gen';
$cs_lang['points'] = 'Beitr&auml;ge';
$cs_lang['rankname'] = 'Rangname';
$cs_lang['new_boardrank'] = 'Neuer Rang';
$cs_lang['id'] = 'ID';

$cs_lang['no_min'] = '- Die Beitr&auml;ge m&uuml;ssen angegeben werden';
$cs_lang['no_name'] = '- Ein Name muss angegeben werden.';

// Remove
$cs_lang['mod_remove'] = 'Forumrang';