<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name'] = 'Lightbox';
$cs_lang['mod_text']  = 'Hilfsmittel zum Anzeigen von Bildern';