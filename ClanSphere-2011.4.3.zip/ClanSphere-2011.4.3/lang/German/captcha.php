<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name']  = 'Sicherheitscodes';
$cs_lang['text']  = 'Schutz vor Robotern';