<?php
$cs_lang['mod_name']  = 'JQuery';
$cs_lang['mod_text']  = 'JavaScript Bibliothek';
