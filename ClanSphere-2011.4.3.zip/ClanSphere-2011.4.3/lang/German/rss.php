<?php
$cs_lang['mod_name']  = 'RSS';
$cs_lang['mod_text']  = 'Bereitstellung maschinenlesbarer Inhalte';
