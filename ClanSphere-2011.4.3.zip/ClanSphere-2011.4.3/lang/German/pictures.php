<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['pictures'] = 'Bilder';
$cs_lang['mod_info'] = 'Bilderverwaltung aller Module';

$cs_lang['picture'] = 'Bild';
$cs_lang['del_picture'] = 'Bild entfernen';