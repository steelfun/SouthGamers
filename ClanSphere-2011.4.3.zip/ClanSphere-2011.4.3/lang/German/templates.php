<?php
// ClanSphere 2010 - www.clansphere.net 
// $Id$

$cs_lang['mod_name']  = 'Templates';
$cs_lang['modinfo']  = 'Verwaltung des User Templates';
$cs_lang['body_temp_list']  = 'Liste der %s vorhandenen Designs.';
$cs_lang['version'] = 'Version';
$cs_lang['active'] = 'Aktiv';