<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name'] = 'Optionen';
$cs_lang['head_roots'] = 'Basis';
$cs_lang['body_roots']  = 'Alle Module die Optionen anbieten.';
$cs_lang['text']  = 'Speichern und Auslesen von Einstellungen';