<?php
// ClanSphere 2010 - www.clansphere.net 
// $Id$

$cs_lang['mod_name'] = 'Benutzer-Galerie';
$cs_lang['modtext'] = 'Multimedia Benutzer-Galerie nutzen und verwalten.';

$cs_lang['not_own'] = 'Das Bild geh&ouml;rt einem anderen Benutzer';

# further translation in gallery.php