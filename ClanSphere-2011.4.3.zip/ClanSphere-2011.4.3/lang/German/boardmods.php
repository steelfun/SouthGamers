<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$ 

$cs_lang['mod_name']   = 'Forummods';
$cs_lang['text'] = 'Das Moderator Modul';

$cs_lang['head_create'] = 'Hinzuf&uuml;gen';
$cs_lang['body'] = 'Bitte alle Felder mit * ausf&uuml;llen.';

$cs_lang['user'] = 'Benutzer';
$cs_lang['rank'] = 'Rang';
$cs_lang['access'] = 'Rechte';
$cs_lang['modpanel'] = 'Modpanel';

$cs_lang['no_cat']  = '- Es muss ein Rang ausgew&auml;hlt bzw. erstellt werden';
$cs_lang['no_user'] = '- Es muss ein Benutzer ausgew&auml;hlt werden.';
$cs_lang['user_exists'] = '- Der ausgew&auml;hlte Benutzer ist bereits eingetragen.';

$cs_lang['new'] = 'Neuer Moderator';

$cs_lang['1'] = 'Ja';
$cs_lang['0'] = 'Nein';

// Remove
$cs_lang['mod_remove'] = 'Forummoderator';
