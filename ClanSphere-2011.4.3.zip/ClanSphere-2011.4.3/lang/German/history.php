<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name']  = 'Geschichte';
$cs_lang['mod_text']  = 'Aktuelle History verwalten und erstellen';

$cs_lang['head_create']  = 'Eintragen';
$cs_lang['body'] =  'Bitte alle Felder mit * ausf&uuml;llen.';

$cs_lang['new_date'] = 'Datum aktualisieren';
$cs_lang['more'] = 'Erweitert';
$cs_lang['text'] = 'History';
$cs_lang['text_list']= 'Ereignisse in der Vergangenheit.';
$cs_lang['new'] = 'Neuer Eintrag';