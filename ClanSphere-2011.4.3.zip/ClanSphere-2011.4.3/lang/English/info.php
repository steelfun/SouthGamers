<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$mod_info['name']    = 'English';
$mod_info['version'] = $cs_main['version_name'];
$mod_info['released'] = $cs_main['version_date'];
$mod_info['creator']  = 'ClanSphere';
$mod_info['team']    = 'ClanSphere';
$mod_info['url']    = 'www.clansphere.net';
$mod_info['text']    = 'Official translation package';
$mod_info['symbol']    = 'gb';