<?php
// ClanSphere 2010 - www.clansphere.net 
// $Id$

$cs_lang['mod_name'] = 'Usersgallery';
$cs_lang['modtext'] = 'Use and manage Multimedia User Gallery';

$cs_lang['not_own'] = '- This image belongs to a different user';

# further translation in gallery.php