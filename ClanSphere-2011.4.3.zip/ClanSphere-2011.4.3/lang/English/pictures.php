<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['pictures'] = 'Pictures';
$cs_lang['mod_info'] = 'Manage the pictures of modules';

$cs_lang['picture'] = 'Picture';
$cs_lang['del_picture'] = 'Remove picture';