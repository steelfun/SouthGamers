<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$com_lang['name']     = 'English';
$com_lang['short']    = 'en';
$com_lang['dateset']  = 'Y-m-d';
$com_lang['timeset']  = 'g:i A';
$com_lang['dtcon']    = 'at';
$com_lang['timename'] = '';
