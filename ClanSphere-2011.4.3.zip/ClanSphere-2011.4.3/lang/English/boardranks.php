<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name'] = 'Boardranks';
$cs_lang['mod_text'] = 'Administrate and Create Boardranks';

$cs_lang['body'] = 'All fields with * are required';

$cs_lang['min'] = 'From posts';
$cs_lang['points'] = 'Points';
$cs_lang['rankname'] = 'Rankname';
$cs_lang['new_boardrank'] = 'New Rank';
$cs_lang['id']='ID';

$cs_lang['no_min'] = '- Posts cannot be empty.';
$cs_lang['no_name'] = '- The name cannot be empty.';

// Remove
$cs_lang['mod_remove'] = 'Boardrank';