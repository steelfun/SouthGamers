<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name'] = 'Options';
$cs_lang['head_roots'] = 'Base';
$cs_lang['body_roots']  = 'All modules that support options.';
$cs_lang['text']  = 'View and Set options';