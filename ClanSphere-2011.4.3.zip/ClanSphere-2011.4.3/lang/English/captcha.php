<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name']  = 'Securitycode';
$cs_lang['text']  = 'Protection of Bots';