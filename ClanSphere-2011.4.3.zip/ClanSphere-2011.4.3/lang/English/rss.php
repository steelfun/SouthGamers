<?php
$cs_lang['mod_name']  = 'RSS';
$cs_lang['mod_text']  = 'Support for Really Simple Syndication';
