<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$ 

$cs_lang['mod_name']  = 'Boardmoderators';
$cs_lang['text']  = 'The moderator module';

$cs_lang['head_create'] = 'Add';
$cs_lang['body'] =  'Please fill out all * marked fields.';

$cs_lang['user'] = 'User';
$cs_lang['rank'] = 'Rank';
$cs_lang['access'] = 'Access';
$cs_lang['modpanel'] = 'Modpanel';

$cs_lang['no_cat'] = '- No rank was selected or created.';
$cs_lang['no_user'] = '- No user was selected.';
$cs_lang['user_exists'] = '- Selected user extists already.';

$cs_lang['new'] = 'New Moderator';

$cs_lang['1'] = 'Yes';
$cs_lang['0'] = 'No';

// Remove
$cs_lang['mod_remove'] = 'Boardmoderator';