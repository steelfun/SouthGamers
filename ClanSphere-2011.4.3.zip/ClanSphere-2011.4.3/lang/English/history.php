<?php
// ClanSphere 2010 - www.clansphere.net
// $Id$

$cs_lang['mod_name']  = 'History';
$cs_lang['mod_text']  = 'Manage and Create History';

$cs_lang['head_create']  = 'Enter';
$cs_lang['body'] =  'All fields marked with * are required.';

$cs_lang['new_date'] = 'Refresh date';
$cs_lang['more'] = 'More';
$cs_lang['text'] = 'History';
$cs_lang['text_list']= 'Events in the past.';
$cs_lang['new'] = 'New entry';