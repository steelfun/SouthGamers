<?php
// ClanSphere 2010 - www.clansphere.net 
// $Id$

$cs_lang['mod_name']  = 'Templates';
$cs_lang['modinfo']  = 'Manage of users templates.';
$cs_lang['body_temp_list']  = 'List of %s available templates.';
$cs_lang['version'] = 'Version';
$cs_lang['active'] = 'Active';